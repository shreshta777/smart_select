"""Keyword matching engine with RapidFuzz alias normalization."""

import re
from typing import Dict, List, Set, Tuple
from rapidfuzz import fuzz

from backend.models import KeywordMatchResult, Resume, JobDescription


# Normalized canonical mapping for common tech skill variations
CANONICAL_SKILL_MAP: Dict[str, List[str]] = {
    "react": ["react", "react.js", "reactjs", "react-js", "react native"],
    "node.js": ["node.js", "nodejs", "node js", "node"],
    "mongodb": ["mongodb", "mongo db", "mongo"],
    "javascript": ["javascript", "js", "ecmascript", "es6", "es6+"],
    "typescript": ["typescript", "ts"],
    "rest apis": ["rest apis", "rest api", "restful apis", "restful api", "restful web services", "rest", "restful"],
    "docker": ["docker", "docker container", "containerization", "containers", "docker-compose"],
    "aws": ["aws", "amazon web services", "amazon aws", "ec2", "s3", "lambda"],
    "python": ["python", "python3", "py"],
    "postgresql": ["postgresql", "postgres", "postgre sql", "psql"],
    "mysql": ["mysql", "my sql", "mariadb"],
    "git": ["git", "github", "gitlab", "version control"],
    "html/css": ["html/css", "html", "css", "html5", "css3"],
    "express": ["express", "express.js", "expressjs"],
    "fastapi": ["fastapi", "fast api"],
    "graphql": ["graphql", "graph ql"],
    "tailwind": ["tailwind", "tailwindcss", "tailwind css"],
    "redux": ["redux", "redux toolkit", "rtk"],
    "next.js": ["next.js", "nextjs", "next js", "next"],
    "vue.js": ["vue.js", "vuejs", "vue"],
    "java": ["java", "core java", "j2ee"],
    "c++": ["c++", "cpp"],
    "c#": ["c#", "csharp", ".net"],
}


def normalize_token(token: str) -> str:
    """Normalizes a single skill string for uniform comparison."""
    if not token:
        return ""
    # Strip punct except dots and pluses (which matter for node.js, c++)
    token = token.lower().strip()
    token = re.sub(r"[\t\r\n]", " ", token)
    token = re.sub(r"\s+", " ", token)
    return token


def get_canonical_name(skill: str) -> str:
    """Finds canonical name if skill matches known aliases."""
    norm = normalize_token(skill)
    for canonical, aliases in CANONICAL_SKILL_MAP.items():
        if norm == canonical or norm in aliases:
            return canonical
        for alias in aliases:
            # High threshold fuzz match on specific known aliases
            if fuzz.ratio(norm, alias) >= 90:
                return canonical
    return norm


def check_skill_in_corpus(target_skill: str, candidate_text: str, candidate_skills: List[str]) -> bool:
    """Checks if a target skill is satisfied in the candidate's profile.
    
    Checks:
    1. Direct list of candidate skills (with canonical mapping & fuzzy match).
    2. Word boundary regex in full resume text.
    3. Alias presence in candidate text.
    """
    target_norm = normalize_token(target_skill)
    target_canon = get_canonical_name(target_skill)

    # 1. Check in candidate explicit skills list
    for c_skill in candidate_skills:
        c_norm = normalize_token(c_skill)
        c_canon = get_canonical_name(c_skill)

        if target_norm == c_norm or target_canon == c_canon:
            return True

        # RapidFuzz similarity check for multi-word or minor typos
        if len(target_norm) > 3 and fuzz.ratio(target_norm, c_norm) >= 88:
            return True

    # 2. Check aliases against full resume text
    aliases_to_check = [target_norm]
    if target_canon in CANONICAL_SKILL_MAP:
        aliases_to_check.extend(CANONICAL_SKILL_MAP[target_canon])

    candidate_text_lower = candidate_text.lower()
    for alias in aliases_to_check:
        escaped_alias = re.escape(alias)
        # Use word boundaries so 'c' doesn't match 'clean' or 'java' inside 'javascript'
        if alias in ["c", "r"]:
            pattern = rf"(?:\b|(?<=[^a-zA-Z0-9])){escaped_alias}(?:\b|(?=[^a-zA-Z0-9]))"
        elif " " in alias or "." in alias or "+" in alias or "#" in alias or "/" in alias:
            pattern = rf"(?:\b|(?<=[^a-zA-Z0-9])){escaped_alias}(?:\b|(?=[^a-zA-Z0-9]))"
        else:
            pattern = rf"\b{escaped_alias}\b"

        if re.search(pattern, candidate_text_lower):
            return True

    return False


def match_keywords(
    jd: JobDescription,
    resume: Resume,
    required_weight: float = 0.7,
    preferred_weight: float = 0.3
) -> KeywordMatchResult:
    """Evaluates candidate against JD using explicit and fuzzy keyword matching."""
    # Build complete searchable text corpus for candidate
    corpus_parts = [
        resume.raw_text,
        " ".join(resume.skills),
        " ".join(resume.experience),
        " ".join(resume.projects),
    ]
    full_corpus = " ".join([p for p in corpus_parts if p])

    # 1. Match Required Skills
    matched_req: List[str] = []
    missing_req: List[str] = []

    for req_skill in jd.required_skills:
        if check_skill_in_corpus(req_skill, full_corpus, resume.skills):
            matched_req.append(req_skill)
        else:
            missing_req.append(req_skill)

    total_req = len(jd.required_skills)
    req_score = (len(matched_req) / total_req * 100.0) if total_req > 0 else 100.0

    # 2. Match Preferred Skills
    matched_pref: List[str] = []
    missing_pref: List[str] = []

    for pref_skill in jd.preferred_skills:
        if check_skill_in_corpus(pref_skill, full_corpus, resume.skills):
            matched_pref.append(pref_skill)
        else:
            missing_pref.append(pref_skill)

    total_pref = len(jd.preferred_skills)
    pref_score = (len(matched_pref) / total_pref * 100.0) if total_pref > 0 else 0.0

    # 3. Calculate Weighted Keyword Score
    if total_pref > 0:
        keyword_score = (required_weight * req_score) + (preferred_weight * pref_score)
    else:
        keyword_score = req_score

    return KeywordMatchResult(
        candidate_id=resume.candidate_id,
        matched_required_skills=matched_req,
        missing_required_skills=missing_req,
        matched_preferred_skills=matched_pref,
        missing_preferred_skills=missing_pref,
        required_skill_score=round(req_score, 1),
        preferred_skill_score=round(pref_score, 1),
        keyword_score=round(keyword_score, 1)
    )
