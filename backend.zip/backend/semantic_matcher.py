"""Semantic matching engine using Sentence Transformers and cosine similarity."""

import logging
from typing import List, Optional, Tuple
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from backend.models import SemanticEvidenceItem, SemanticMatchResult, Resume, JobDescription

logger = logging.getLogger(__name__)

# Global model singleton
_EMBEDDING_MODEL = None
MODEL_NAME = "all-MiniLM-L6-v2"


def get_embedding_model():
    """Loads and caches the SentenceTransformer model."""
    global _EMBEDDING_MODEL
    if _EMBEDDING_MODEL is None:
        try:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading SentenceTransformer model '{MODEL_NAME}'...")
            _EMBEDDING_MODEL = SentenceTransformer(MODEL_NAME)
            logger.info("SentenceTransformer model loaded successfully.")
        except Exception as e:
            logger.warning(f"Could not load SentenceTransformer '{MODEL_NAME}': {e}. Using TF-IDF fallback.")
            _EMBEDDING_MODEL = "TFIDF_FALLBACK"
    return _EMBEDDING_MODEL


def encode_texts(texts: List[str], model=None) -> np.ndarray:
    """Generates normalized vector embeddings for a list of text strings."""
    if not texts:
        return np.empty((0, 384))

    if model is None:
        model = get_embedding_model()

    if model != "TFIDF_FALLBACK":
        embeddings = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True, show_progress_bar=False)
        return embeddings
    else:
        # Graceful TF-IDF fallback if sentence-transformers is unavailable
        from sklearn.feature_extraction.text import TfidfVectorizer
        vec = TfidfVectorizer(ngram_range=(1, 2))
        return vec.fit_transform(texts).toarray()


def compute_semantic_match(
    jd: JobDescription,
    resume: Resume,
    top_k_evidence: int = 3
) -> SemanticMatchResult:
    """Calculates semantic similarity between JD and Resume content."""
    model = get_embedding_model()

    # 1. Compile JD semantic target units
    jd_targets: List[str] = []
    for resp in jd.responsibilities:
        if resp.strip():
            jd_targets.append(resp.strip())

    for req in jd.required_skills:
        jd_targets.append(f"Proficient in {req}")

    for pref in jd.preferred_skills:
        jd_targets.append(f"Experience with {pref}")

    if not jd_targets and jd.description:
        jd_targets = [line.strip() for line in jd.description.split("\n") if len(line.strip()) > 15]

    if not jd_targets:
        jd_targets = ["Full stack development with frontend and backend services."]

    # 2. Compile Candidate semantic evidence units
    candidate_items: List[str] = []
    exp_count = 0
    proj_count = 0

    for exp in resume.experience:
        if exp.strip():
            candidate_items.append(exp.strip())
            exp_count += 1

    for proj in resume.projects:
        if proj.strip():
            candidate_items.append(proj.strip())
            proj_count += 1

    # Add skills overview sentence if candidate items are sparse
    if resume.skills:
        candidate_items.append("Skills: " + ", ".join(resume.skills))

    if not candidate_items and resume.raw_text:
        candidate_items = [line.strip() for line in resume.raw_text.split("\n") if len(line.strip()) > 15]

    if not candidate_items:
        return SemanticMatchResult(
            candidate_id=resume.candidate_id,
            semantic_score=0.0,
            experience_similarity=0.0,
            project_similarity=0.0,
            key_semantic_matches=[]
        )

    # 3. Compute dense vector embeddings
    jd_embeddings = encode_texts(jd_targets, model=model)
    cand_embeddings = encode_texts(candidate_items, model=model)

    if jd_embeddings.shape[0] == 0 or cand_embeddings.shape[0] == 0:
        return SemanticMatchResult(
            candidate_id=resume.candidate_id,
            semantic_score=0.0,
            experience_similarity=0.0,
            project_similarity=0.0,
            key_semantic_matches=[]
        )

    # 4. Compute cosine similarity matrix (shape: len(jd_targets) x len(candidate_items))
    if model != "TFIDF_FALLBACK":
        sim_matrix = np.dot(jd_embeddings, cand_embeddings.T)
    else:
        # For fallback array
        from sklearn.metrics.pairwise import cosine_similarity as cos_sim
        sim_matrix = cos_sim(jd_embeddings, cand_embeddings)

    # For each JD target, find candidate's maximum matching item score
    max_per_target = np.max(sim_matrix, axis=1)

    # Average match across JD targets (scale to 0-100)
    # Give slightly higher weight to the top matching targets (top 80%)
    sorted_target_scores = np.sort(max_per_target)[::-1]
    top_subset_len = max(1, int(np.ceil(len(sorted_target_scores) * 0.8)))
    effective_score = float(np.mean(sorted_target_scores[:top_subset_len]))

    # Scale and clip score nicely between 0 and 100
    semantic_score = float(np.clip(effective_score * 100.0, 0.0, 100.0))

    # Calculate sub-section similarities
    exp_sim = 0.0
    if exp_count > 0:
        exp_matrix = sim_matrix[:, :exp_count]
        exp_sim = float(np.mean(np.max(exp_matrix, axis=1))) * 100.0

    proj_sim = 0.0
    if proj_count > 0 and (exp_count + proj_count) <= sim_matrix.shape[1]:
        proj_matrix = sim_matrix[:, exp_count:exp_count + proj_count]
        proj_sim = float(np.mean(np.max(proj_matrix, axis=1))) * 100.0

    # 5. Extract top-K semantic evidence pairs
    evidence_pairs: List[Tuple[float, str, str]] = []
    for i, jd_item in enumerate(jd_targets):
        for j, cand_item in enumerate(candidate_items):
            sim = float(sim_matrix[i, j])
            evidence_pairs.append((sim, jd_item, cand_item))

    # Sort descending by similarity
    evidence_pairs.sort(key=lambda x: x[0], reverse=True)

    # Deduplicate candidate items to give diverse evidence
    seen_cand = set()
    top_evidence_items: List[SemanticEvidenceItem] = []
    for sim, jd_t, cand_t in evidence_pairs:
        if cand_t not in seen_cand and sim > 0.40:
            seen_cand.add(cand_t)
            top_evidence_items.append(
                SemanticEvidenceItem(
                    jd_item=jd_t,
                    candidate_evidence=cand_t,
                    similarity_score=round(sim, 3)
                )
            )
            if len(top_evidence_items) >= top_k_evidence:
                break

    return SemanticMatchResult(
        candidate_id=resume.candidate_id,
        semantic_score=round(semantic_score, 1),
        experience_similarity=round(exp_sim, 1),
        project_similarity=round(proj_sim, 1),
        key_semantic_matches=top_evidence_items
    )
