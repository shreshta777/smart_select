"""Data models and schemas for InternLoom Smart Shortlisting Engine."""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class Resume(BaseModel):
    """Standardized representation of a candidate's resume."""
    candidate_id: str
    name: str = "Unknown Candidate"
    skills: List[str] = Field(default_factory=list)
    experience: List[str] = Field(default_factory=list)
    projects: List[str] = Field(default_factory=list)
    education: List[str] = Field(default_factory=list)
    certifications: List[str] = Field(default_factory=list)
    raw_text: str = ""


class JobDescription(BaseModel):
    """Standardized representation of a Job Description."""
    job_title: str = "Job Opening"
    company: Optional[str] = "Company"
    required_skills: List[str] = Field(default_factory=list)
    preferred_skills: List[str] = Field(default_factory=list)
    responsibilities: List[str] = Field(default_factory=list)
    education_requirements: List[str] = Field(default_factory=list)
    experience_requirements: List[str] = Field(default_factory=list)
    description: str = ""
    raw_text: str = ""


class KeywordMatchResult(BaseModel):
    """Keyword match details for a candidate against a JD."""
    candidate_id: str
    matched_required_skills: List[str] = Field(default_factory=list)
    missing_required_skills: List[str] = Field(default_factory=list)
    matched_preferred_skills: List[str] = Field(default_factory=list)
    missing_preferred_skills: List[str] = Field(default_factory=list)
    required_skill_score: float = 0.0  # 0 to 100
    preferred_skill_score: float = 0.0  # 0 to 100
    keyword_score: float = 0.0  # 0 to 100


class SemanticEvidenceItem(BaseModel):
    """Individual semantic alignment between JD item and resume section."""
    jd_item: str
    candidate_evidence: str
    similarity_score: float  # 0.0 to 1.0


class SemanticMatchResult(BaseModel):
    """Semantic match details for a candidate."""
    candidate_id: str
    semantic_score: float = 0.0  # 0 to 100
    experience_similarity: float = 0.0
    project_similarity: float = 0.0
    key_semantic_matches: List[SemanticEvidenceItem] = Field(default_factory=list)


class CandidateEvaluation(BaseModel):
    """Consolidated evaluation record for a candidate."""
    candidate_id: str
    name: str
    final_score: float
    keyword_score: float
    semantic_score: float
    required_skill_score: float
    preferred_skill_score: float
    matched_required_skills: List[str] = Field(default_factory=list)
    missing_required_skills: List[str] = Field(default_factory=list)
    matched_preferred_skills: List[str] = Field(default_factory=list)
    missing_preferred_skills: List[str] = Field(default_factory=list)
    key_semantic_matches: List[SemanticEvidenceItem] = Field(default_factory=list)
    skills: List[str] = Field(default_factory=list)
    experience: List[str] = Field(default_factory=list)
    projects: List[str] = Field(default_factory=list)
    education: List[str] = Field(default_factory=list)


class Top3Explanation(BaseModel):
    """Structured explanation for top-ranked candidates."""
    rank: int
    candidate_id: str
    name: str
    score: float
    keyword_score: float
    semantic_score: float
    why_ranked: str
    matched_skills: List[str]
    missing_skills: List[str]
    matched_preferred: List[str]
    semantic_evidence: List[str]


class ComparisonResult(BaseModel):
    """Comparison between Candidate A and Candidate B."""
    candidate_a_id: str
    candidate_a_name: str
    candidate_a_score: float
    candidate_a_keyword: float
    candidate_a_semantic: float
    candidate_a_req_matched: int
    candidate_a_req_total: int
    candidate_a_missing: List[str]

    candidate_b_id: str
    candidate_b_name: str
    candidate_b_score: float
    candidate_b_keyword: float
    candidate_b_semantic: float
    candidate_b_req_matched: int
    candidate_b_req_total: int
    candidate_b_missing: List[str]

    higher_ranked_candidate: str
    score_delta: float
    summary: str
    key_differentiators: List[str]


class JDBiasItem(BaseModel):
    category: str
    flagged_text: str
    explanation: str
    recommendation: str


class JDBiasAnalysis(BaseModel):
    has_flags: bool
    summary: str
    flags: List[JDBiasItem] = Field(default_factory=list)


class RankedCandidate(BaseModel):
    rank: int
    evaluation: CandidateEvaluation
    explanation: Optional[Top3Explanation] = None


class ShortlistResponse(BaseModel):
    job_title: str
    total_candidates: int
    weights: Dict[str, float]
    rankings: List[RankedCandidate]
    top_3_explanations: List[Top3Explanation]
    jd_analysis: Optional[JDBiasAnalysis] = None
