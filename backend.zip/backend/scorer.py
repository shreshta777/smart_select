"""Scoring engine for combining keyword and semantic match outputs."""

from backend.models import (
    CandidateEvaluation,
    KeywordMatchResult,
    SemanticMatchResult,
    Resume,
)


def evaluate_candidate(
    resume: Resume,
    kw_result: KeywordMatchResult,
    sem_result: SemanticMatchResult,
    keyword_weight: float = 0.5,
    semantic_weight: float = 0.5,
) -> CandidateEvaluation:
    """Combines keyword and semantic scores into an explainable final score."""
    # Normalize weights if needed
    total_w = keyword_weight + semantic_weight
    w_kw = keyword_weight / total_w if total_w > 0 else 0.5
    w_sem = semantic_weight / total_w if total_w > 0 else 0.5

    final_score = (w_kw * kw_result.keyword_score) + (w_sem * sem_result.semantic_score)
    final_score = round(final_score, 1)

    return CandidateEvaluation(
        candidate_id=resume.candidate_id,
        name=resume.name,
        final_score=final_score,
        keyword_score=kw_result.keyword_score,
        semantic_score=sem_result.semantic_score,
        required_skill_score=kw_result.required_skill_score,
        preferred_skill_score=kw_result.preferred_skill_score,
        matched_required_skills=kw_result.matched_required_skills,
        missing_required_skills=kw_result.missing_required_skills,
        matched_preferred_skills=kw_result.matched_preferred_skills,
        missing_preferred_skills=kw_result.missing_preferred_skills,
        key_semantic_matches=sem_result.key_semantic_matches,
        skills=resume.skills,
        experience=resume.experience,
        projects=resume.projects,
        education=resume.education,
    )
